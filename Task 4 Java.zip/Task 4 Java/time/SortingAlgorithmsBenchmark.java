package vm222cv_assign4.time;

import java.util.Comparator;
import java.util.Random;
import vm222cv_assign4.time.SortingAlgorithms;

public class SortingAlgorithmsBenchmark 
{
	public static void main(String[] args)
	{
		//intInsertionSortTest();
		//intMergeSortTest();
		//stringInsertionSortTest();
		//stringMergeSortTest();
	}
	
	public static void intInsertionSortTest()
	{	
		int arr[] = createRandomIntArray(2000,4000);
		long time = 0;
		while(time < 1000)
		{
			long start = System.currentTimeMillis();
			SortingAlgorithms.insertionSort(arr);
			long end = System.currentTimeMillis();
			time = end - start;
			System.out.println("Time: " + time + " milliseconds. Length: " + arr.length);
			if (time == 999 || time == 1000 || time == 1001)
			{ 
				break;
			} 
			else if (time > 1001 && time <= 1050)
			{
				arr = createRandomIntArray(arr.length - 1, arr.length * 2); 
				time = 0;
			}
			else if (time > 1050)
			{
				arr = createRandomIntArray(arr.length - 500, arr.length * 2);
				time = 0;
			} 
			else if (time <= 950)
			{
				arr = createRandomIntArray(arr.length + 500, arr.length * 2);
				time = 0;
			} 
			else 
			{
				arr = createRandomIntArray(arr.length + 1, arr.length * 2);
			}
		}
	}
	

	public static void intMergeSortTest()
	{
		int arr[] = createRandomIntArray(2000,4000);
		long time = 0;
		while(time < 1000)
		{
			long start = System.currentTimeMillis();
			SortingAlgorithms.mergeSort(arr);
			long end = System.currentTimeMillis();
			time = end - start;
			System.out.println("Time: " + time + " milliseconds. Length: " + arr.length);
			if (time == 999 || time == 1000 || time == 1001)
			{ 
				break;
			} 
			else if (time > 1001 && time <= 1050)
			{
				arr = createRandomIntArray(arr.length - 1, arr.length * 2); 
				time = 0;
			}
			else if (time > 1050)
			{
				arr = createRandomIntArray(arr.length - 1000, arr.length * 2);
				time = 0;
			} 
			else if (time <= 950)
			{
				arr = createRandomIntArray(arr.length + 1000, arr.length * 2);
				time = 0;
			} 
			else 
			{
				arr = createRandomIntArray(arr.length + 1, arr.length * 2);
			}
		}
	}
	
	public static void stringInsertionSortTest()
	{
		String[] arr = createRandomStringArray(2000,4000);
		Comparator<String> c = (String s1, String s2) -> s1.compareTo(s2);
		long time = 0;
		while(time < 1000)
		{
			long start = System.currentTimeMillis();
			SortingAlgorithms.insertionSort(arr,c);
			long end = System.currentTimeMillis();
			time = end - start;
			System.out.println("Time: " + time + " milliseconds. Length: " + arr.length);
			if (time == 999 || time == 1000 || time == 1001)
			{ 
				break;
			} 
			else if (time > 1001 && time <= 1050)
			{
				arr = createRandomStringArray(arr.length - 1, arr.length * 2); 
				time = 0;
			}
			else if (time > 1050)
			{
				arr = createRandomStringArray(arr.length - 500, arr.length * 2);
				time = 0;
			} 
			else if (time <= 950)
			{
				arr = createRandomStringArray(arr.length + 500, arr.length * 2);
				time = 0;
			} 
			else
			{
				arr = createRandomStringArray(arr.length + 1, arr.length * 2);
			}
		}
	}

	public static void stringMergeSortTest()
	{
		String[] arr = createRandomStringArray(2000,4000);
		Comparator<String> c = (String s1, String s2) -> s1.compareTo(s2);
		long time = 0;
		while(time < 1000)
		{
			long start = System.currentTimeMillis();
			SortingAlgorithms.mergeSort(arr,c);
			long end = System.currentTimeMillis();
			time = end - start;
			System.out.println("Time: " + time + " milliseconds. Length: " + arr.length);
			if (time == 999 || time == 1000 || time == 1001)
			{ 
				break;
			} 
			else if (time > 1001 && time <= 1050)
			{
				arr = createRandomStringArray(arr.length - 1, arr.length * 2); 
				time = 0;
			}
			else if (time > 1050)
			{
				arr = createRandomStringArray(arr.length - 1000, arr.length * 2);
				time = 0;
			} 
			else if (time <= 950)
			{
				arr = createRandomStringArray(arr.length + 1000, arr.length * 2);
				time = 0;
			} 
			else 
			{
				arr = createRandomStringArray(arr.length + 1, arr.length * 2);
			}
		}
		
	}
	
	/*------------------------Helper methods------------------------*/
	private static int[] createRandomIntArray(int size, int n) 
	{
		
		Random rand = new Random();
		int[] arr = new int[size];
		
		for (int i = 0; i < arr.length; i++)
		{
			arr[i] = rand.nextInt(n);
		}
		return arr;
	}
	
	
	private static String[] createRandomStringArray(int size, int n) 
	{
		Random random = new Random();
		String[] randomStringArray = new String[size];
		String[] alphabet =  { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r",
				"s", "t", "u", "v", "w", "x", "y", "z" };
		
		if (n >= alphabet.length || n <= 0)	
		{
			n = alphabet.length;
		}
		StringBuilder sb;
		
		for (int i = 0; i < randomStringArray.length; i++) 
		{
			sb = new StringBuilder();
			int siz = 0;
			while (siz != 10)
			{
				sb.append(alphabet[random.nextInt(n)]);
				siz++;
			}
			randomStringArray[i] = sb.toString();
		}

		return randomStringArray;
	}
}